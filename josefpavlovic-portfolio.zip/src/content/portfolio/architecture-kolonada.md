---
title: "Mariánské Lázně — Kolonáda"
category: architecture
date: "2025-09-15"
cover: /images/portfolio/architecture-01.jpg
featured: true
order: 1
images:
  - src: /images/portfolio/architecture-01.jpg
    alt: "Hlavní kolonáda v ranním světle"
    caption: "Zpívající fontána, ráno"
  - src: /images/portfolio/architecture-02.jpg
    alt: "Detail litinové konstrukce"
    caption: "Litinové ornamenty kolonády"
---

Architektonické fotografie kolonády a lázeňských budov v Mariánských Lázních. Zaměřeno na světlo, textury a geometrii secesní a klasicistní architektury.

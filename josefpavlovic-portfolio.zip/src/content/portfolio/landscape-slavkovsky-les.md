---
title: "Slavkovský les"
category: landscape
date: "2025-08-10"
cover: /images/portfolio/landscape-01.jpg
featured: false
order: 3
images:
  - src: /images/portfolio/landscape-01.jpg
    alt: "Mlha nad Slavkovským lesem"
    caption: "Ranní mlha, Kladská"
---

Krajina západních Čech — Slavkovský les, Kladská, okolí Mariánských Lázní.

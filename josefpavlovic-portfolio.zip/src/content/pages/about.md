---
title: "O mně"
description: "Josef Pavlovic — fotograf z Mariánských Lázní"
layout: default
---

## Josef Pavlovic

Fotograf z Mariánských Lázní se zaměřením na architekturu, portréty, krajinu a street fotografii.

Žiji v lázeňském městě, které mě neustále inspiruje svou architekturou, přírodou a atmosférou. Fotím jak komerční zakázky (real estate, eventy), tak osobní projekty.

### Kontakt

- **Email:** foto@josefpavlovic.cz
- **Instagram:** @josefpavlovic
- **Lokalita:** Mariánské Lázně, Česká republika

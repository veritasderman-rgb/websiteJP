import { defineCollection, z } from 'astro:content';

const portfolio = defineCollection({
  type: 'content',
  schema: z.object({
    title: z.string(),
    category: z.enum([
      'architecture',
      'portraits',
      'landscape',
      'street',
      'events',
      'nudes',
    ]),
    date: z.string(),
    cover: z.string(),
    images: z.array(
      z.object({
        src: z.string(),
        alt: z.string().optional().default(''),
        caption: z.string().optional().default(''),
      })
    ).optional().default([]),
    featured: z.boolean().optional().default(false),
    draft: z.boolean().optional().default(false),
    order: z.number().optional().default(0),
  }),
});

const pages = defineCollection({
  type: 'content',
  schema: z.object({
    title: z.string(),
    description: z.string().optional().default(''),
    layout: z.string().optional().default('default'),
  }),
});

export const collections = { portfolio, pages };
